package projectActivities

class Activity1a {
	static void main(def args) {
		def inputList = [11, 2, 19, 5, "Mango", "Apple", "Watermelon"]
		
		def intList = inputList.minus(["Mango", "Apple", "Watermelon"])
		
		def strList = inputList.minus([11, 2, 19, 5])
		
		println intList.sort()
		println strList.sort()
	}
}
